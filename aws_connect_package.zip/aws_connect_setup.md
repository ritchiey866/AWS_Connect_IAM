# AWS Connect User Setup Guide

This document provides step-by-step instructions to configure authentication and authorization in AWS Connect.

## Key Steps
1. Login to AWS Connect Admin UI
2. Go to Users → User Management
3. Add or Edit User
4. Assign Security Profile (Authorization)
5. Assign Routing Profile (Agents)
6. Save and Validate

Refer to full checklist for detailed steps.
