# AWS Connect Checklist

- [ ] Login to AWS Connect
- [ ] Open User Management
- [ ] Create or Edit User
- [ ] Assign Security Profile
- [ ] Assign Routing Profile
- [ ] Save User
- [ ] Validate Login
